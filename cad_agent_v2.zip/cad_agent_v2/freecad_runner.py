"""Run trusted compiled code in a fresh process and a new attempt directory."""
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile


def discover_command():
    configured = os.environ.get("CAD_FREECAD_COMMAND")
    if configured:
        command = json.loads(configured)
        if not isinstance(command,list) or not command or any(not isinstance(x,str) for x in command):
            raise ValueError("CAD_FREECAD_COMMAND must be a JSON argv list")
        return command
    # Debian's external Python binding works even when FreeCADCmd's startup
    # fails. The Python version must match FreeCAD.so, not the app's venv.
    if Path("/usr/lib/freecad-python3/lib/FreeCAD.so").is_file() and Path("/usr/bin/python3").is_file():
        return ["/usr/bin/python3"]
    for name in ("FreeCADCmd","freecadcmd","FreeCADcmd"):
        found = shutil.which(name)
        if found:
            return [found]
    raise FileNotFoundError("FreeCAD runtime unavailable. Set CAD_FREECAD_COMMAND to a JSON list containing the ABI-compatible Python or FreeCADCmd executable.")


def _log_tail(path):
    with path.open("rb") as file:
        file.seek(0,2); file.seek(max(0,file.tell()-6000))
        return file.read().decode("utf-8",errors="replace")


class FreeCADRunner:
    def __init__(self, command=None, timeout=90):
        self.command = command
        self.timeout = timeout

    def run(self, source, directory):
        directory = Path(directory).resolve(); directory.mkdir(parents=True,exist_ok=True)
        attempt = Path(tempfile.mkdtemp(prefix="attempt-",dir=directory))
        script = attempt/"generated_model.py"; script.write_text(source,encoding="utf-8")
        stdout_path = attempt/"stdout.log"; stderr_path = attempt/"stderr.log"
        result = {"ok":False, "return_code":None, "error":None, "attempt_directory":str(attempt),
                  "script_path":str(script), "runtime":None, "failure_kind":None}
        try:
            command = self.command or discover_command()
            env = os.environ.copy(); env["CAD_OUTPUT_DIR"] = str(attempt)
            env["PYTHONNOUSERSITE"] = "1"
            # Do not inject app-venv package paths into the FreeCAD interpreter.
            env.pop("PYTHONPATH",None)
            with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
                process = subprocess.Popen([*command,str(script)],cwd=attempt,env=env,
                    stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=os.name=="posix")
                try:
                    process.wait(timeout=self.timeout)
                except subprocess.TimeoutExpired:
                    if os.name == "posix":
                        os.killpg(process.pid,signal.SIGKILL)
                    else:
                        process.kill()
                    process.wait()
                    result.update(error=f"FreeCAD timed out after {self.timeout}s",failure_kind="timeout")
            result["return_code"] = process.returncode
            report_path = attempt/"runtime_report.json"
            if report_path.is_file():
                runtime = json.loads(report_path.read_text(encoding="utf-8"))
                if not isinstance(runtime,dict):
                    raise ValueError("runtime report must be a JSON object")
                result["runtime"] = runtime
                result["ok"] = bool(process.returncode == 0 and runtime.get("ok") and not result["error"])
                if not result["ok"] and not result["error"]:
                    result["error"] = runtime.get("error") or "CAD failed declared acceptance checks"
                    result["failure_kind"] = runtime.get('failure_kind') or "geometry"
            elif not result["error"]:
                result.update(error="FreeCAD did not produce a runtime report",failure_kind="environment")
            if process.returncode != 0 and not result["failure_kind"]:
                result["failure_kind"] = "environment"
        except (OSError,ValueError) as exc:
            result.update(error=str(exc),failure_kind="environment")
        result["stdout_tail"] = _log_tail(stdout_path) if stdout_path.exists() else ""
        result["stderr_tail"] = _log_tail(stderr_path) if stderr_path.exists() else ""
        return result
