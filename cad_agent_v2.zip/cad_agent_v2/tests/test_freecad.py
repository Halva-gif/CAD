import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

from compiler import compile_design
from freecad_runner import FreeCADRunner
from main import CadPipeline
from schemas import CadDesign
from validation import validate_run

ROOT=Path(__file__).resolve().parents[1]


def program(features,final=None,checks=None,solids=1):
    final=final or features[-1]['id']
    return CadDesign.model_validate(dict(goal='Integration fixture',constraints=[],parameters=[],features=features,
        outputs=[dict(feature=final,label=final,expected_solids=solids)],
        checks=checks or [dict(kind='volume',target=final,minimum=0.0001,maximum=1e9,reason='Fixture should contain material')],manual_review=[]))


def rectangle(name,z=0,size=10):
    corners=[(0,0),(size,0),(size,size),(0,size)]
    def p(xy): return dict(x=xy[0],y=xy[1],z=z)
    return dict(id=name,op='profile',intent='Closed square',segments=[
        dict(kind='line',start=p(corners[i]),end=p(corners[(i+1)%4])) for i in range(4)])


@unittest.skipUnless(os.environ.get('CAD_RUN_INTEGRATION')=='1','Set CAD_RUN_INTEGRATION=1 to execute real FreeCAD')
class FreeCADTests(unittest.TestCase):
    def run_design(self,design,expect=True):
        with tempfile.TemporaryDirectory() as directory:
            run=FreeCADRunner().run(compile_design(design),directory)
            report=validate_run(design,run)
            self.assertEqual(report['passed'],expect,json.dumps(run,indent=2)[-10000:])
            return run

    def test_curved_glass_and_normal_wall(self):
        d=CadDesign.model_validate(json.loads((ROOT/'examples/glass.json').read_text()))
        run=self.run_design(d)
        metrics=run['runtime']['metrics'][0]
        self.assertAlmostEqual(metrics['bbox']['z_max']-metrics['bbox']['z_min'],100,places=4)
        self.assertAlmostEqual(metrics['bbox']['x_max']-metrics['bbox']['x_min'],76,places=4)
        self.assertTrue(any(c['detail']=='normal_wall_thickness' and c['passed'] for c in run['runtime']['checks']))

    def test_through_holes(self):
        self.run_design(CadDesign.model_validate(json.loads((ROOT/'examples/plate.json').read_text())))

    def test_box_cylinder_sphere_cone(self):
        for feature in [dict(id='B',op='box',intent='Box',length=10,width=20,height=30),
                        dict(id='C',op='cylinder',intent='Cylinder',radius=4,height=10),
                        dict(id='S',op='sphere',intent='Sphere',radius=4),
                        dict(id='N',op='cone',intent='Cone',radius1=5,radius2=2,height=10)]:
            with self.subTest(op=feature['op']): self.run_design(program([feature]))

    def test_profile_extrude(self):
        d=program([rectangle('Profile'),dict(id='Pad',op='extrude',intent='Pad',profile='Profile',vector=dict(x=0,y=0,z=8))],checks=[dict(kind='bbox',target='Pad',axis='z',expected=8,tolerance=0.001,reason='Extrusion depth')])
        self.run_design(d)

    def test_arc_and_bezier_profile(self):
        def p(x,y):return dict(x=x,y=y,z=0)
        profile=dict(id='Curves',op='profile',intent='Curved closed profile',segments=[
            dict(kind='bezier',points=[p(0,0),p(3,-2),p(7,-2),p(10,0)]),
            dict(kind='line',start=p(10,0),end=p(10,10)),
            dict(kind='arc',start=p(10,10),mid=p(5,12),end=p(0,10)),
            dict(kind='line',start=p(0,10),end=p(0,0))])
        self.run_design(program([profile,dict(id='Solid',op='extrude',intent='Curved prismatic solid',profile='Curves',vector=dict(z=5))]))

    def test_profile_revolve(self):
        p=rectangle('Profile')
        # Put rectangle in XZ plane, with radii from 2 to 12.
        for segment in p['segments']:
            for key in ('start','end'):
                pt=segment[key]; pt['z']=pt['y']; pt['y']=0; pt['x']+=2
        d=program([p,dict(id='Revolved',op='revolve',intent='Revolved tube',profile='Profile')])
        self.run_design(d)

    def test_loft(self):
        self.run_design(program([rectangle('A'),rectangle('B',z=20,size=5),dict(id='Loft',op='loft',intent='Tapered loft',profiles=['A','B'])]))

    def test_fuse_common_and_transform(self):
        for op in ['fuse','common']:
            features=[dict(id='A',op='box',intent='First box',length=10,width=10,height=10),
                dict(id='B',op='box',intent='Overlapping box',length=10,width=10,height=10,origin=dict(x=5,y=0,z=0)),
                dict(id='Joined',op=op,intent='CSG operation',inputs=['A','B']),
                dict(id='Final',op='transform',intent='Rigid placement',base='Joined',translation=dict(x=7,y=8,z=9),axis=dict(x=0,y=0,z=1),angle=90)]
            with self.subTest(op=op): self.run_design(program(features))

    def test_fillet_and_chamfer(self):
        for op in ['fillet','chamfer']:
            d=program([dict(id='Box',op='box',intent='Box',length=10,width=10,height=10),dict(id='Dressed',op=op,intent='Dressed edge',base='Box',radius=1,edges=[1])])
            with self.subTest(op=op): self.run_design(d)

    def test_linear_pattern_holes(self):
        d=program([dict(id='Blank',op='box',intent='Plate',length=40,width=10,height=4),
            dict(id='Tool',op='cylinder',intent='Hole',radius=1,height=6,origin=dict(x=5,y=5,z=-1)),
            dict(id='Row',op='linear_pattern',intent='Three hole tools',base='Tool',count=3,delta=dict(x=10)),
            dict(id='Plate',op='cut',intent='Three through holes',base='Blank',tool='Row')],
            checks=[dict(kind='point',target='Plate',point=dict(x=x,y=5,z=2),inside=False,reason='Open hole') for x in [5,15,25]])
        self.run_design(d)

    def test_polar_pattern(self):
        d=program([dict(id='Source',op='cylinder',intent='Pin',radius=1,height=5,origin=dict(x=10)),
            dict(id='Pins',op='polar_pattern',intent='Four pins',base='Source',count=4,angle_step=90)],solids=4)
        self.run_design(d)

    def test_open_profile_is_rejected(self):
        profile=rectangle('Profile'); profile['segments'][-1]['end']['x']=1
        d=program([profile,dict(id='Pad',op='extrude',intent='Bad pad',profile='Profile',vector=dict(z=8))])
        self.run_design(d,False)

    def test_disjoint_cut_is_rejected(self):
        d=program([dict(id='Box',op='box',intent='Box',length=10,width=10,height=10),dict(id='Tool',op='cylinder',intent='Disjoint tool',radius=2,height=10,origin=dict(x=50)),dict(id='Cut',op='cut',intent='No-op cut',base='Box',tool='Tool')])
        self.run_design(d,False)

    def test_disconnected_fuse_rejects_expected_one_solid(self):
        d=program([dict(id='A',op='box',intent='Box A',length=10,width=10,height=10),dict(id='B',op='box',intent='Box B',length=10,width=10,height=10,origin=dict(x=50)),dict(id='Joined',op='fuse',intent='Disjoint fuse',inputs=['A','B'])])
        self.run_design(d,False)

    def test_wrong_geometry_not_published(self):
        data=json.loads((ROOT/'examples/glass.json').read_text()); data['checks'][0]['expected']=999
        with tempfile.TemporaryDirectory() as directory:
            state=CadPipeline().run('',directory,True,design=data)
            self.assertEqual(state['status'],'failed')
            self.assertFalse((Path(state['delivery_directory'])/'model.FCStd').exists())

    def test_repair_gets_runtime_feedback_and_is_bounded(self):
        good=json.loads((ROOT/'examples/glass.json').read_text())
        bad=copy.deepcopy(good); bad['features'][0]['height']='height*0.9'
        class Planner:
            usage=[]
            def __init__(self): self.inputs=[]
            def propose(self,**kwargs):
                self.inputs.append(kwargs)
                return dict(status='ready',questions=[],explanation='',design=bad if len(self.inputs)==1 else good)
        planner=Planner()
        with tempfile.TemporaryDirectory() as directory:
            state=CadPipeline(planner).run('a smooth curved glass',directory,True)
            self.assertEqual(state['status'],'validated',state['error'])
            self.assertEqual(state['usage']['planner_calls'],2)
            self.assertTrue(planner.inputs[1]['feedback']['failed_checks'])
            self.assertTrue((Path(state['delivery_directory'])/'model.FCStd').is_file())

    def test_runner_timeout(self):
        with tempfile.TemporaryDirectory() as directory:
            run=FreeCADRunner(command=[sys.executable],timeout=0.1).run('import time\ntime.sleep(5)',directory)
            self.assertEqual(run['failure_kind'],'timeout')
            self.assertFalse(run['ok'])
