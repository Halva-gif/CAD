import copy
import json
from pathlib import Path
import tempfile
import unittest

from compiler import MissingParameters, compile_design
from expressions import evaluate, number_tokens
from knowledge import KnowledgeIndex, markdown_chunks
from main import CadPipeline
from planner import OpenAIPlanner, PlannerUnavailable
from schemas import CadDesign, PlanResponse, validate_request_facts
from validation import lock_repair, validate_run

ROOT = Path(__file__).resolve().parents[1]


def glass():
    return json.loads((ROOT/'examples/glass.json').read_text())


class ContractTests(unittest.TestCase):
    def test_expression_injection_is_rejected(self):
        for value in ["__import__('os').system('id')","height.__class__","[1][0]","1 ** 20","True","'2'"]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                evaluate(value,{'height':100})

    def test_expression_limits_and_division(self):
        for value in ['1/0','1e300','100001','h+missing']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                evaluate(value,{'h':5})
        self.assertEqual(evaluate('2*h + h/2',{'h':4}),10)

    def test_unicode_numbers(self):
        self.assertEqual(number_tokens('ارتفاع ۱۰۰ و ضخامت ۳٫۵ mm'),[100,3.5])
        self.assertEqual(number_tokens('3D plate 80x60x6mm, radius 1e1mm'),[80,60,6,10])

    def test_unit_conversion(self):
        data=glass(); data['parameters'][0].update(value=10,unit='cm')
        self.assertEqual(CadDesign.model_validate(data).canonical_parameters()['height'],100)

    def test_unknown_dimensions_block_compilation(self):
        data=glass(); data['parameters'][0].update(status='unknown',value=None,unit=None,reason=None)
        with self.assertRaises(MissingParameters): compile_design(CadDesign.model_validate(data))

    def test_unknown_value_cannot_hide_as_default(self):
        data=glass(); data['parameters'][0]['status']='unknown'
        with self.assertRaises(ValueError): CadDesign.model_validate(data)

    def test_duplicate_parameter_and_feature_names(self):
        data=glass(); data['parameters'].append(copy.deepcopy(data['parameters'][0]))
        with self.assertRaises(ValueError): CadDesign.model_validate(data)
        data=glass(); data['features'].append(copy.deepcopy(data['features'][0]))
        with self.assertRaises(ValueError): CadDesign.model_validate(data)

    def test_invalid_feature_references(self):
        data=glass(); data['features'].insert(0,dict(id='Broken',op='cut',intent='Bad reference',base='Glass',tool='missing'))
        with self.assertRaises(ValueError): CadDesign.model_validate(data)

    def test_unused_parameters_and_features_are_rejected(self):
        data=glass(); data['parameters'].append(dict(name='unused',value=5,unit='mm',status='assumed',reason='test',evidence=None))
        with self.assertRaises(ValueError): CadDesign.model_validate(data)
        data=glass(); data['features'].append(dict(id='Tool',op='sphere',intent='Unused',radius=2))
        with self.assertRaises(ValueError): CadDesign.model_validate(data)

    def test_unsupported_operation_is_rejected(self):
        data=glass(); data['features'][0]['op']='hallucinated_surface'
        with self.assertRaises(ValueError): CadDesign.model_validate(data)

    def test_plan_requires_independent_check_for_each_output(self):
        data=glass(); data['checks']=[]
        with self.assertRaises(ValueError): CadDesign.model_validate(data)

    def test_given_evidence_and_missing_request_numbers(self):
        data=glass(); data['parameters'][0].update(status='given',evidence='height 100 mm',reason=None)
        design=CadDesign.model_validate(data)
        validate_request_facts(design,'glass height 100 mm',True)
        with self.assertRaises(ValueError): validate_request_facts(design,'glass height 101 mm',True)
        with self.assertRaises(ValueError): validate_request_facts(design,'glass height 100 mm, radius 42 mm',True)

    def test_millimetres_cannot_be_relabelled_metres(self):
        data=glass(); data['parameters'][0].update(status='given',evidence='height 100 mm',unit='m',reason=None)
        with self.assertRaises(ValueError): validate_request_facts(CadDesign.model_validate(data),'height 100 mm',True)

    def test_literal_dimensional_assumptions_are_rejected(self):
        data=glass(); data['features'][0]['base_radius']='base_radius+9'
        with self.assertRaises(ValueError): validate_request_facts(CadDesign.model_validate(data),'glass',True)
        data['features'][0]['rim_radius']=38
        data['features'][0]['base_radius']='base_radius+rim_radius*0'
        with self.assertRaises(ValueError): validate_request_facts(CadDesign.model_validate(data),'glass',True)

    def test_angle_unit_cannot_be_used_as_height(self):
        data=glass(); data['parameters'][0]['unit']='deg'
        with self.assertRaises(ValueError): validate_request_facts(CadDesign.model_validate(data),'glass',True)

    def test_defaults_need_explicit_policy(self):
        with self.assertRaises(ValueError): validate_request_facts(CadDesign.model_validate(glass()),'glass')

    def test_repair_cannot_weaken_acceptance_or_change_assumptions(self):
        original=CadDesign.model_validate(glass())
        revised=original.model_copy(deep=True); revised.checks[0].tolerance=1
        with self.assertRaises(ValueError): lock_repair(original,revised)
        revised=original.model_copy(deep=True); revised.parameters[0].value=50
        with self.assertRaises(ValueError): lock_repair(original,revised)

    def test_generated_script_quotes_user_data(self):
        text="quote ' ; __import__('os').system('id')\nend"
        source=compile_design(CadDesign.model_validate(glass()),text)
        self.assertIn('REQUEST = '+repr(text),source)

    def test_missing_runtime_cannot_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            report=validate_run(CadDesign.model_validate(glass()),dict(ok=True,return_code=0,attempt_directory=directory,runtime=None))
            self.assertFalse(report['passed'])

    def test_nonready_response_has_clear_questions(self):
        with self.assertRaises(ValueError): PlanResponse(status='needs_clarification',questions=[],explanation='',design=None)


class RetrievalTests(unittest.TestCase):
    def test_fenced_code_is_not_cut_at_heading(self):
        text='# Intro\ntext\n## Example\n```python\n# not a heading\nprint(1)\n```\n## Tail\nend'
        chunks=markdown_chunks(text)
        self.assertEqual(len(chunks),3)
        self.assertIn('# not a heading\nprint(1)',chunks[1][1])

    def test_late_sections_and_code_examples_survive_retrieval(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); wiki=root/'wiki'; wiki.mkdir()
            (root/'catalog.json').write_text(json.dumps({'revolve.md':'revolve face profile'}))
            text=''.join(f'## Section {i}\nordinary text\n' for i in range(20))+'## Revolve\n```python\nsolid = face.revolve(origin, axis, 360)\n```\n'
            (wiki/'revolve.md').write_text(text)
            index=KnowledgeIndex(root/'catalog.json',wiki,root/'cache')
            result=index.retrieve('revolve curved profile')
            self.assertTrue(any('face.revolve' in s['text'] for s in result['snippets']))
            cached_files=list((root/'cache').glob('*.json'))
            self.assertEqual(len(cached_files),1)
            (wiki/'revolve.md').write_text(text+'## New\nrevolve changed API\n')
            index.retrieve('revolve')
            self.assertEqual(len(list((root/'cache').glob('*.json'))),2)

    def test_catalog_names_cannot_escape_wiki(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); (root/'outside.md').write_text('secret')
            (root/'wiki').mkdir(); (root/'catalog.json').write_text(json.dumps({'../outside.md':'revolve'}))
            index=KnowledgeIndex(root/'catalog.json',root/'wiki',root/'cache')
            self.assertEqual(index.retrieve('revolve')['selected_files'],[])

    def test_no_docs_is_reported_and_oversize_code_not_truncated(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); (root/'wiki').mkdir()
            (root/'catalog.json').write_text(json.dumps({'doc.md':'revolve'}))
            index=KnowledgeIndex(root/'catalog.json',root/'wiki',root/'cache')
            self.assertTrue(index.retrieve('revolve')['warnings'])
            (root/'wiki'/'doc.md').write_text('## Revolve\n```python\n'+('revolve = 1\n'*50)+'```')
            result=index.retrieve('revolve',max_characters=100)
            self.assertEqual(result['snippets'],[])
            self.assertTrue(result['warnings'])


class FakePlanner:
    usage=[]
    def __init__(self,responses): self.responses=iter(responses); self.inputs=[]
    def propose(self,**kwargs):
        self.inputs.append(kwargs)
        response=next(self.responses)
        if isinstance(response,Exception): raise response
        return response


class NeverRunner:
    def run(self,*args): raise AssertionError('execution should not be reached')


class PipelineTests(unittest.TestCase):
    def test_clarification_uses_one_call_and_no_runtime(self):
        planner=FakePlanner([dict(status='needs_clarification',questions=['Height in mm?'],explanation='Dimensions missing',design=None)])
        with tempfile.TemporaryDirectory() as directory:
            state=CadPipeline(planner,NeverRunner()).run('a glass',directory)
            self.assertEqual(state['status'],'needs_clarification')
            self.assertEqual(state['usage']['planner_calls'],1)
            self.assertFalse((Path(state['delivery_directory'])/'model.FCStd').exists())

    def test_unknowns_do_not_trigger_futile_code_repairs(self):
        data=glass(); data['parameters'][0].update(status='unknown',value=None,unit=None,reason=None)
        planner=FakePlanner([dict(status='ready',questions=[],explanation='',design=data)])
        with tempfile.TemporaryDirectory() as directory:
            state=CadPipeline(planner,NeverRunner()).run('a glass',directory,True)
            self.assertEqual(state['status'],'needs_clarification')
            self.assertEqual(len(planner.inputs),1)

    def test_disabled_defaults_ask_for_dimensions_once(self):
        planner=FakePlanner([dict(status='ready',questions=[],explanation='',design=glass())])
        with tempfile.TemporaryDirectory() as directory:
            state=CadPipeline(planner,NeverRunner()).run('a glass',directory,False)
            self.assertEqual(state['status'],'needs_clarification')
            self.assertEqual(len(planner.inputs),1)

    def test_contract_retries_are_bounded(self):
        planner=FakePlanner([ValueError('invalid plan')]*3)
        with tempfile.TemporaryDirectory() as directory:
            state=CadPipeline(planner,NeverRunner(),max_repairs=2).run('a glass',directory)
            self.assertEqual(state['status'],'failed')
            self.assertEqual(state['usage']['planner_calls'],3)

    def test_provider_error_stops_without_geometry_retry(self):
        planner=FakePlanner([PlannerUnavailable('Authentication failed')])
        with tempfile.TemporaryDirectory() as directory:
            state=CadPipeline(planner,NeverRunner()).run('a glass',directory)
            self.assertEqual(state['status'],'environment_error')
            self.assertEqual(state['usage']['planner_calls'],1)

    def test_invalid_repair_budget_is_rejected(self):
        with self.assertRaises(ValueError): CadPipeline(max_repairs=4)
