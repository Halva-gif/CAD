"""Exercise the real OpenAI SDK and JSON schema with a mock HTTP transport.

No API credentials or paid calls are required. This is transport/contract coverage,
not an evaluation of an actual model's CAD reasoning.
"""
import importlib.util
import json
import os
from pathlib import Path
import unittest
from unittest.mock import patch

from planner import OpenAIPlanner, PlannerUnavailable
from schemas import CadDesign

ROOT=Path(__file__).resolve().parents[1]
HAS_SDK=bool(importlib.util.find_spec('openai'))


@unittest.skipUnless(HAS_SDK,'Install requirements-llm.txt for SDK transport tests')
class ProviderTests(unittest.TestCase):
    def check_proxy_request(self, explicit_url):
        import httpx
        from openai import OpenAI as RealOpenAI
        captured=[]
        def handler(request):
            captured.append(request)
            return httpx.Response(200,json=dict(id='chatcmpl-test',object='chat.completion',created=1,model='proxy-model',
                choices=[dict(index=0,finish_reason='stop',message=dict(role='assistant',content=None,refusal='Test response'))],usage=None))
        clients=[]
        def factory(**kwargs):
            client=RealOpenAI(http_client=httpx.Client(transport=httpx.MockTransport(handler)),**kwargs)
            clients.append(client)
            return client
        with patch.dict(os.environ,{'OPENAI_API_KEY':'test-proxy-key','OPENAI_BASE_URL':'https://env-proxy.example.test/v1'}),patch('openai.OpenAI',side_effect=factory):
            planner=OpenAIPlanner(model='proxy-model',base_url=explicit_url)
            try: planner.propose('glass',{},True)
            finally:
                for client in clients: client.close()
        self.assertEqual(str(captured[0].url),(explicit_url or 'https://env-proxy.example.test/v1')+'/chat/completions')
        body=json.loads(captured[0].content)
        self.assertEqual(body['model'],'proxy-model')
        self.assertEqual(body['response_format']['type'],'json_schema')

    def test_explicit_base_url_overrides_environment_and_routes_request(self):
        self.check_proxy_request('https://explicit-proxy.example.test/v1')

    def test_environment_base_url_routes_request(self):
        self.check_proxy_request(None)

    def planner(self,handler):
        import httpx
        from openai import OpenAI
        client=OpenAI(api_key='test-key-not-a-real-credential',max_retries=0,
            http_client=httpx.Client(transport=httpx.MockTransport(handler)))
        self.addCleanup(client.close)
        return OpenAIPlanner(model='test-structured-model',client=client)

    def test_sdk_serializes_strict_schema_and_parses_plan(self):
        import httpx
        captured=[]
        design=CadDesign.model_validate(json.loads((ROOT/'examples/glass.json').read_text())).model_dump(mode='json')
        def handler(request):
            captured.append(json.loads(request.content))
            return httpx.Response(200,json=dict(id='chatcmpl-test',object='chat.completion',created=1,model='test-structured-model',
                choices=[dict(index=0,finish_reason='stop',message=dict(role='assistant',content=json.dumps(dict(status='ready',questions=[],explanation='Planned',design=design))))],
                usage=dict(prompt_tokens=100,completion_tokens=200,total_tokens=300)))
        planner=self.planner(handler)
        response=planner.propose('a curved glass',{},True)
        self.assertEqual(response.design.outputs[0].feature,'Glass')
        self.assertTrue(captured[0]['response_format']['json_schema']['strict'])
        self.assertEqual(planner.usage[0]['total_tokens'],300)
        self.assertEqual(planner.calls,1)
        def validate(schema):
            if isinstance(schema,dict):
                if schema.get('type')=='object':
                    self.assertFalse(schema.get('additionalProperties',True))
                    self.assertEqual(set(schema.get('required',[])),set(schema.get('properties',{})))
                for value in schema.values(): validate(value)
            elif isinstance(schema,list):
                for value in schema: validate(value)
        validate(captured[0]['response_format']['json_schema']['schema'])

    def test_provider_authentication_error_is_not_cad_repair(self):
        import httpx
        planner=self.planner(lambda request:httpx.Response(401,json={'error':{'message':'Invalid key','type':'authentication_error'}}))
        with self.assertRaises(PlannerUnavailable): planner.propose('glass',{},True)
        self.assertEqual(planner.calls,1)

    def test_provider_refusal_returns_explicit_unsupported(self):
        import httpx
        def handler(request):
            return httpx.Response(200,json=dict(id='chatcmpl-test',object='chat.completion',created=1,model='test',
                choices=[dict(index=0,finish_reason='stop',message=dict(role='assistant',content=None,refusal='Unsupported request'))],usage=None))
        response=self.planner(handler).propose('glass',{},True)
        self.assertEqual(response.status,'unsupported')
