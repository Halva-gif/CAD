"""CAD Agent v2: request -> typed plan -> trusted compiler -> FreeCAD -> checks.

Offline: python main.py --plan examples/glass.json --allow-defaults --out runs
Online:  python main.py --request '...' --model YOUR_MODEL --out runs
"""
import argparse
import json
from pathlib import Path
import shutil
import tempfile

from compiler import MissingParameters, compile_design
from freecad_runner import FreeCADRunner
from knowledge import KnowledgeIndex
from planner import OpenAIPlanner, PlannerUnavailable
from schemas import CadDesign, PlanResponse, validate_request_facts
from validation import lock_repair, validate_run

ROOT = Path(__file__).resolve().parent


def _write(path, data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")


class CadPipeline:
    def __init__(self, planner=None, runner=None, index=None, max_repairs=2):
        if not 0 <= max_repairs <= 3:
            raise ValueError("max_repairs must be between 0 and 3")
        self.planner = planner; self.runner = runner or FreeCADRunner()
        self.index = index or KnowledgeIndex(ROOT/"document_chooser.json",ROOT/"py_wiki",ROOT/".cache"/"knowledge")
        self.max_repairs = max_repairs

    def run(self, request, output_directory, allow_defaults=False, design=None):
        output_directory = Path(output_directory).resolve(); output_directory.mkdir(parents=True,exist_ok=True)
        run_dir = Path(tempfile.mkdtemp(prefix="run-",dir=output_directory))
        retrieval = self.index.retrieve(request)
        state = {"schema_version":2,"status":"failed","request":request,"delivery_directory":str(run_dir),
                 "design":None,"knowledge":retrieval,"script_path":None,"run_result":None,
                 "validation":None,"assumptions":[],"questions":[],"error":None,"attempts":[],"usage":{}}
        original = None; feedback = None; calls = 0
        fixed_design = CadDesign.model_validate(design) if design is not None else None
        limit = 1 if fixed_design is not None else 1+self.max_repairs
        for attempt in range(limit):
            record = {"attempt":attempt+1,"planner_called":False,"error":None}
            state["attempts"].append(record)
            try:
                if fixed_design is not None:
                    candidate = fixed_design
                else:
                    if self.planner is None:
                        raise PlannerUnavailable("No planner configured")
                    record["planner_called"] = True; calls += 1
                    response = self.planner.propose(request=request,knowledge=retrieval,allow_defaults=allow_defaults,
                        previous=state["design"],feedback=feedback)
                    response = PlanResponse.model_validate(response)
                    if response.status != "ready":
                        state.update(status=response.status,questions=response.questions,error=response.explanation)
                        break
                    candidate = response.design
                unresolved = [p for p in candidate.parameters if p.status=='unknown' or (p.status=='assumed' and not allow_defaults)]
                if unresolved:
                    state.update(status='needs_clarification',design=candidate.model_dump(mode='json'),
                        error='Resolve dimensions or explicitly enable recorded defaults.',
                        questions=[f'Specify value and unit for {p.name}' for p in unresolved])
                    break
                if request:
                    validate_request_facts(candidate,request,allow_defaults)
                elif not allow_defaults and any(p.status=="assumed" for p in candidate.parameters):
                    raise ValueError("Plan contains assumed dimensions; use --allow-defaults to accept them")
                if original is not None:
                    lock_repair(original,candidate)
                if original is None:
                    original = candidate.model_copy(deep=True)
                state["design"] = candidate.model_dump(mode="json")
                state["assumptions"] = [p.model_dump() for p in candidate.parameters if p.status=="assumed"]
                source = compile_design(candidate,request)
                _write(run_dir/f"design-attempt-{attempt+1}.json",state["design"])
                record["feature_count"] = len(candidate.features)
                run = self.runner.run(source,run_dir/"attempts")
                state["run_result"] = run; record["run_directory"] = run["attempt_directory"]
                validation = validate_run(candidate,run)
                state["validation"] = validation
                if validation["passed"]:
                    runtime = run["runtime"]
                    for src,name in ((runtime["fcstd_path"],"model.FCStd"),(runtime["step_path"],"model.step"),
                                     (run["script_path"],"generated_model.py")):
                        shutil.copy2(src,run_dir/name)
                    _write(run_dir/"design.json",state["design"])
                    _write(run_dir/"validation.json",validation)
                    _write(run_dir/"runtime_report.json",runtime)
                    state.update(status="validated",error=None,script_path=str(run_dir/"generated_model.py"))
                    break
                feedback = {"failed_feature":(run.get("runtime") or {}).get("failed_feature"),
                            "error":run.get("error"),
                            "failed_checks":[c for c in validation["checks"] if not c["passed"]]}
                record["error"] = feedback; state["error"] = feedback
                if run.get("failure_kind") in ("environment","timeout"):
                    state["status"] = "environment_error"
                    break
                retrieval = self.index.retrieve(request,[f.op for f in candidate.features])
            except MissingParameters as exc:
                state.update(status="needs_clarification",error=str(exc),
                    questions=[f"Specify value and unit for {p.name}" for p in candidate.parameters if p.status=="unknown"])
                record["error"] = str(exc)
                break
            except PlannerUnavailable as exc:
                state.update(status="environment_error",error=str(exc)); record["error"] = str(exc)
                break
            except ValueError as exc:
                feedback = {"contract_error":str(exc)}; record["error"] = feedback; state["error"] = feedback
        state["usage"] = {"planner_calls":calls,"embedding_calls":0,
                          "tokens":getattr(self.planner,"usage",[]) if self.planner else []}
        _write(run_dir/"result.json",state)
        return state


def cli(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--request",help="User's natural-language CAD request")
    source.add_argument("--plan",type=Path,help="An already reviewed v2 design.json (no API call)")
    source.add_argument("--demo",choices=["glass","plate"],help="Offline demonstration with explicitly assumed dimensions")
    parser.add_argument("--out",type=Path,default=Path("runs"))
    parser.add_argument("--allow-defaults",action="store_true",help="Permit explicitly recorded dimensional assumptions")
    parser.add_argument("--model",help="A structured-output model available in your API account")
    parser.add_argument('--base-url',help='OpenAI-compatible provider API base URL, e.g. https://proxy.example/v1; overrides OPENAI_BASE_URL')
    parser.add_argument("--max-repairs",type=int,default=2)
    parser.add_argument("--timeout",type=float,default=90)
    args = parser.parse_args(argv)
    if args.timeout <= 0:
        parser.error("timeout must be positive")
    planner = None; design = None; request = args.request or ""
    if args.demo:
        design = json.loads((ROOT/"examples"/(args.demo+".json")).read_text(encoding="utf-8"))
        args.allow_defaults = True
    elif args.plan:
        design = json.loads(args.plan.read_text(encoding="utf-8"))
    else:
        try:
            from dotenv import load_dotenv
            load_dotenv(ROOT/".env")
        except ImportError:
            pass
        try:
            planner = OpenAIPlanner(args.model,base_url=args.base_url)
        except PlannerUnavailable as exc:
            print(json.dumps({"status":"environment_error","error":str(exc)},ensure_ascii=False))
            return 2
    try:
        result = CadPipeline(planner=planner,runner=FreeCADRunner(timeout=args.timeout),max_repairs=args.max_repairs).run(
            request,args.out,allow_defaults=args.allow_defaults,design=design)
    except (ValueError,OSError) as exc:
        print(json.dumps({'status':'failed','error':str(exc)},ensure_ascii=False))
        return 2
    print(json.dumps({k:result[k] for k in ("status","delivery_directory","questions","error","assumptions","usage")},ensure_ascii=False,indent=2))
    return 0 if result["status"]=="validated" else 2


if __name__ == "__main__":
    raise SystemExit(cli())
