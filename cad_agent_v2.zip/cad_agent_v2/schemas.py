"""Version 2 contract: a typed CAD construction program, not untrusted Python."""
import math
import re
from typing import Literal, Union
from pydantic import BaseModel, ConfigDict, Field, model_validator

from expressions import UNITS, dimensionality, evaluate, expression_names, number_tokens

Scalar = Union[float, str]
Name = str


class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Parameter(Contract):
    name: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_]{0,47}$")
    value: float | None
    unit: Literal["mm", "cm", "m", "in", "deg", "rad", "count"] | None
    status: Literal["given", "assumed", "unknown"]
    evidence: str | None = Field(description="Exact request substring for given values; null otherwise")
    reason: str | None = Field(description="Explicit reason for a default; null for given values")

    @model_validator(mode="after")
    def provenance(self):
        if self.status == "unknown":
            if self.value is not None or self.unit is not None:
                raise ValueError("unknown parameter must have null value and unit")
        elif self.value is None or self.unit is None:
            raise ValueError("resolved parameter needs a value and unit")
        if self.status == "given" and not self.evidence:
            raise ValueError("given parameter needs source evidence")
        if self.status == "assumed" and not self.reason:
            raise ValueError("assumed parameter needs a reason")
        return self

    def canonical(self):
        return None if self.value is None else evaluate(self.value * UNITS[self.unit], {})


class Point(Contract):
    x: Scalar = 0.0
    y: Scalar = 0.0
    z: Scalar = 0.0


class Feature(Contract):
    id: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_]{0,47}$")
    intent: str = Field(min_length=1, max_length=500)


class Box(Feature):
    op: Literal["box"]
    length: Scalar
    width: Scalar
    height: Scalar
    origin: Point = Field(default_factory=Point)


class Cylinder(Feature):
    op: Literal["cylinder"]
    radius: Scalar
    height: Scalar
    origin: Point = Field(default_factory=Point)


class Sphere(Feature):
    op: Literal["sphere"]
    radius: Scalar
    center: Point = Field(default_factory=Point)


class Cone(Feature):
    op: Literal["cone"]
    radius1: Scalar
    radius2: Scalar
    height: Scalar
    origin: Point = Field(default_factory=Point)


class Line(Contract):
    kind: Literal["line"]
    start: Point
    end: Point


class Arc(Contract):
    kind: Literal["arc"]
    start: Point
    mid: Point
    end: Point


class Bezier(Contract):
    kind: Literal["bezier"]
    points: list[Point] = Field(min_length=3, max_length=6)


class Profile(Feature):
    op: Literal["profile"]
    segments: list[Union[Line, Arc, Bezier]] = Field(min_length=2, max_length=128)


class Extrude(Feature):
    op: Literal["extrude"]
    profile: Name
    vector: Point


class Revolve(Feature):
    op: Literal["revolve"]
    profile: Name
    origin: Point = Field(default_factory=Point)
    axis: Point = Field(default_factory=lambda: Point(z=1))
    angle: Scalar = 360.0


class Loft(Feature):
    op: Literal["loft"]
    profiles: list[Name] = Field(min_length=2, max_length=16)
    ruled: bool = False


class Cut(Feature):
    op: Literal["cut"]
    base: Name
    tool: Name


class Fuse(Feature):
    op: Literal["fuse", "common"]
    inputs: list[Name] = Field(min_length=2, max_length=16)


class DressUp(Feature):
    op: Literal["fillet", "chamfer"]
    base: Name
    radius: Scalar
    edges: list[int] = Field(min_length=1, max_length=128, description="1-based edge indices in this source version; avoid for unstable topology")


class Transform(Feature):
    op: Literal["transform"]
    base: Name
    translation: Point = Field(default_factory=Point)
    axis: Point = Field(default_factory=lambda: Point(z=1))
    angle: Scalar = 0.0


class LinearPattern(Feature):
    op: Literal['linear_pattern']
    base: Name
    count: Scalar
    delta: Point


class PolarPattern(Feature):
    op: Literal['polar_pattern']
    base: Name
    count: Scalar
    origin: Point = Field(default_factory=Point)
    axis: Point = Field(default_factory=lambda:Point(z=1))
    angle_step: Scalar


class Vessel(Feature):
    """Circular walls with exact normal thickness and a tangent round lip."""
    op: Literal["vessel"]
    height: Scalar
    rim_radius: Scalar
    base_radius: Scalar
    wall_thickness: Scalar
    bottom_thickness: Scalar
    bulge: Scalar = Field(description="Positive radial deviation at half height from a straight taper")


CADFeature = Union[Box, Cylinder, Sphere, Cone, Profile, Extrude, Revolve, Loft,
                   Cut, Fuse, DressUp, Transform, LinearPattern, PolarPattern, Vessel]


class Output(Contract):
    feature: Name
    label: str
    expected_solids: int = Field(default=1, ge=1, le=16)


class BBoxCheck(Contract):
    kind: Literal["bbox"]
    target: Name
    axis: Literal["x", "y", "z"]
    expected: Scalar
    tolerance: float = Field(default=0.01, gt=0, le=10)
    reason: str


class PointCheck(Contract):
    kind: Literal["point"]
    target: Name
    point: Point
    inside: bool
    reason: str


class VolumeCheck(Contract):
    kind: Literal["volume"]
    target: Name
    minimum: Scalar
    maximum: Scalar
    reason: str


AcceptanceCheck = Union[BBoxCheck, PointCheck, VolumeCheck]


def references(feature):
    op = feature.op
    if op in ("extrude", "revolve"):
        return [feature.profile]
    if op == "loft":
        return feature.profiles
    if op == "cut":
        return [feature.base, feature.tool]
    if op in ("fuse", "common"):
        return feature.inputs
    if op in ("fillet", "chamfer", "transform", 'linear_pattern','polar_pattern'):
        return [feature.base]
    return []


def scalar_fields(item):
    if isinstance(item, Point):
        yield from (item.x, item.y, item.z)
    elif isinstance(item, BaseModel):
        for key, value in item.__dict__.items():
            if key in {"length", "width", "height", "radius", "radius1", "radius2", "angle",
                       "rim_radius", "base_radius", "wall_thickness", "bottom_thickness",
                       "bulge", "expected", "minimum", "maximum",'count','angle_step'}:
                yield value
            elif isinstance(value, (BaseModel, list)):
                yield from scalar_fields(value)
    elif isinstance(item, list):
        for value in item:
            yield from scalar_fields(value)


class CadDesign(Contract):
    schema_version: Literal[2] = 2
    goal: str
    constraints: list[str]
    parameters: list[Parameter] = Field(max_length=128)
    features: list[CADFeature] = Field(min_length=1, max_length=64)
    outputs: list[Output] = Field(min_length=1, max_length=16)
    checks: list[AcceptanceCheck] = Field(min_length=1, max_length=128)
    manual_review: list[str] = Field(description="Qualities not certified by executable checks, including aesthetics")

    @model_validator(mode="after")
    def program_integrity(self):
        names = [p.name for p in self.parameters]
        if len(names) != len(set(names)):
            raise ValueError("duplicate parameter names")
        seen = {}
        for feature in self.features:
            if feature.id in seen or feature.id in {"Parameters", "OriginalRequest"}:
                raise ValueError(f"duplicate/reserved feature id {feature.id}")
            for ref in references(feature):
                if ref not in seen:
                    raise ValueError(f"{feature.id} references later or unknown feature {ref}")
            profile_refs = references(feature) if feature.op in ("extrude", "revolve", "loft") else []
            if any(seen[ref].op != "profile" for ref in profile_refs):
                raise ValueError("extrude/revolve/loft requires closed profile features")
            if feature.op in ("cut", "fuse", "common", "fillet", "chamfer", "transform",'linear_pattern','polar_pattern'):
                if any(seen[ref].op == "profile" for ref in references(feature)):
                    raise ValueError("solid operation cannot consume a profile")
            seen[feature.id] = feature
        output_ids = [o.feature for o in self.outputs]
        if len(set(output_ids)) != len(output_ids):
            raise ValueError("duplicate final output")
        for output in self.outputs:
            if output.feature not in seen or seen[output.feature].op == "profile":
                raise ValueError("final output must reference a solid feature")
        for check in self.checks:
            if check.target not in output_ids:
                raise ValueError("checks must target a final output")
        if set(output_ids) - {c.target for c in self.checks}:
            raise ValueError("each output needs an acceptance check")
        used = set().union(*(expression_names(s) for s in scalar_fields(self.features)))
        if used - set(names):
            raise ValueError(f"unknown parameters: {sorted(used - set(names))}")
        if set(names) - used:
            raise ValueError(f"parameters not used in geometry: {sorted(set(names) - used)}")
        for scalar in scalar_fields(self.checks):
            if expression_names(scalar) - set(names):
                raise ValueError("check references unknown parameters")
        # A final feature and its ancestors account for every construction step.
        live = set(output_ids)
        for feature in reversed(self.features):
            if feature.id in live:
                live.update(references(feature))
        if set(seen) - live:
            raise ValueError(f"unused features: {sorted(set(seen) - live)}")
        return self

    def canonical_parameters(self):
        return {p.name: p.canonical() for p in self.parameters}


class PlanResponse(Contract):
    status: Literal["ready", "needs_clarification", "unsupported"]
    questions: list[str]
    explanation: str
    design: CadDesign | None

    @model_validator(mode="after")
    def disposition(self):
        if self.status == "ready" and (self.design is None or self.questions):
            raise ValueError("ready requires a design and no unanswered questions")
        if self.status == "needs_clarification" and not self.questions:
            raise ValueError("clarification requires concrete questions")
        return self


def validate_request_facts(design, request, allow_defaults=False):
    given_numbers = []
    for parameter in design.parameters:
        if parameter.status == "given":
            if parameter.evidence not in request:
                raise ValueError(f"evidence missing from request for {parameter.name}")
            if not any(math.isclose(parameter.value, n, rel_tol=1e-10, abs_tol=1e-10)
                       for n in number_tokens(parameter.evidence)):
                raise ValueError(f"given value {parameter.name} does not match its evidence")
            given_numbers.append(parameter.value)
        elif parameter.status == "assumed" and not allow_defaults:
            raise ValueError(f"defaults are disabled: {parameter.name}")
    missed = [n for n in number_tokens(request) if not any(math.isclose(n, v, rel_tol=1e-10, abs_tol=1e-10) for v in given_numbers)]
    if missed:
        raise ValueError(f"request numbers were dropped: {missed}; represent counts/angles too or ask for clarification")
    # A source number is not sufficient provenance for its unit.
    # Order longer unit names before their substrings (mm is not m).
    unit_pattern = re.compile(r'(?<![A-Za-z])(millimet(?:er|re)s?|mm|میلی\s*متر|میلیمتر|'
        r'centimet(?:er|re)s?|cm|سانتی\s*متر|سانتیمتر|inches|inch|in|اینچ|"|'
        r'radians?|rad|رادیان|degrees?|deg|درجه|°|meters?|metres?|m|متر)(?![A-Za-z])',re.I)
    def matched_unit(token):
        s = re.sub(r'\s+','',token.lower())
        if s in ('mm','میلیمتر') or s.startswith('millimet'): return 'mm'
        if s in ('cm','سانتیمتر') or s.startswith('centimet'): return 'cm'
        if s in ('in','inch','inches','اینچ','"'): return 'in'
        if s in ('rad','radian','radians','رادیان'): return 'rad'
        if s in ('deg','degree','degrees','درجه','°'): return 'deg'
        return 'm'
    for parameter in design.parameters:
        if parameter.status == "given" and parameter.unit != "count":
            text = parameter.evidence.replace('\u200c',' ')
            found_units = {matched_unit(token) for token in unit_pattern.findall(text)}
            if parameter.unit not in found_units:
                raise ValueError(f"unit for {parameter.name} needs evidence (include shared unit text in evidence)")
    validate_physical_dimensions(design,require_tracked=True)


def validate_physical_dimensions(design, require_tracked=False):
    units = {p.name:p.unit for p in design.parameters}
    def check_scalar(value,expected):
        names=expression_names(value)
        dimension=dimensionality(value,units)
        if names and dimension not in (None,expected):
            raise ValueError(f'expression has wrong physical dimensions: {value}')
        if require_tracked and not names and dimension is not None and expected==(1,0):
            raise ValueError('untracked dimensional literal; declare it as a given or assumed parameter')
    def verify_dimensions(item, dimensionless=False):
        if isinstance(item, Point):
            values = [item.x,item.y,item.z]
        elif isinstance(item, BaseModel):
            values = []
            for key,value in item.__dict__.items():
                if key in ('angle','angle_step'):
                    check_scalar(value,(0,1))
                elif key=='count':
                    check_scalar(value,(0,0))
                elif isinstance(value, (BaseModel,list)):
                    verify_dimensions(value,key=='axis')
                elif key in {'length','width','height','radius','radius1','radius2','rim_radius',
                             'base_radius','wall_thickness','bottom_thickness','bulge'}:
                    values.append(value)
        elif isinstance(item,list):
            for value in item: verify_dimensions(value,dimensionless)
            return
        else:
            return
        for value in values:
            check_scalar(value,(0,0) if dimensionless else (1,0))
    verify_dimensions(design.features)
    for check in design.checks:
        if check.kind=='bbox': check_scalar(check.expected,(1,0))
        elif check.kind=='point': verify_dimensions(check.point)
        else:
            check_scalar(check.minimum,(3,0)); check_scalar(check.maximum,(3,0))
