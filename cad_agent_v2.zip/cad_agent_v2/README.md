# CAD Agent v2

هستهٔ اصلاح‌شده برای تبدیل درخواست متنی به CAD در FreeCAD. مدل زبانی یک برنامهٔ هندسی JSON با schema مشخص می‌دهد؛ کامپایلر و اجرای CAD، قطعی و قابل آزمون هستند.

```mermaid
flowchart LR
    U[درخواست کاربر] --> K[بازیابی محلی دانش]
    K --> P[طرح ساختاریافته؛ یک فراخوانی مدل]
    P --> C[کنترل قرارداد و واحدها]
    C --> B[کامپایلر پایتون FreeCAD]
    B --> F[اجرای FreeCAD در فرایند تازه]
    F --> V[اعتبارسنجی هندسه و بازخوانی فایل]
    V -->|قبول| O[FCStd و STEP و کد و گزارش]
    V -->|خطای هندسی؛ بودجه باقی است| P
    P -->|اطلاعات ناکافی| Q[سؤال روشن برای کاربر]
```

## اجرای نمونه بدون API

Python برنامهٔ اصلی باید نسخهٔ 3.10 یا جدیدتر و Pydantic نسخهٔ 2 داشته باشد. Python اجرای FreeCAD می‌تواند جدا باشد و باید با باینری FreeCAD سازگار باشد.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python main.py --demo glass --out runs
python main.py --demo plate --out runs
```

در Windows برای فعال‌سازی محیط مجازی از `.venv\Scripts\activate` استفاده کنید. نمونه‌ها عمداً اندازه‌های فرضی ثبت‌شده دارند. برای اجرای طرح خودتان:

```bash
python main.py --plan examples/glass.json --allow-defaults --out runs
```

هر اجرا پوشهٔ تازهٔ `run-*` می‌سازد. فقط پس از عبور از بررسی‌ها، `model.FCStd`، `model.step`، `generated_model.py`، `design.json`، `validation.json` و `runtime_report.json` در آن قرار می‌گیرند. تلاش‌های ناموفق در `attempts/` می‌مانند و به‌عنوان نتیجهٔ پذیرفته‌شده منتشر نمی‌شوند. `result.json` شامل وضعیت، هزینهٔ ثبت‌شده، فرض‌ها و خطاهاست.

## اتصال مدل زبانی

```bash
python -m pip install -r requirements-llm.txt
cp .env.example .env
```

در `.env`، `OPENAI_API_KEY` و `CAD_PLANNER_MODEL` را با مقادیر حساب خودتان تنظیم کنید. نام مدل پیش‌فرض فرض نشده است؛ مدل انتخابی باید structured outputs را پشتیبانی کند.

```bash
python main.py --request "یک لیوان با بدنهٔ نرم و منحنی" --out runs
python main.py --request "یک لیوان با بدنهٔ نرم و منحنی" --allow-defaults --out runs
```

اجرای اول برای اندازه‌های نامشخص سؤال برمی‌گرداند. اجرای دوم اجازهٔ اندازه‌های فرضیِ آشکار را می‌دهد. فرض‌ها در JSON و خروجی CLI دیده می‌شوند. پاسخی با وضعیت `needs_clarification` را به رابط کاربری برگردانید؛ پاسخ کاربر را به متن درخواست اضافه کنید و دوباره اجرا کنید. `unsupported` یعنی درخواست در مجموعهٔ عملیات فعلی قابل بیان نیست.

از Python هم می‌توانید استفاده کنید:

```python
from main import CadPipeline
from planner import OpenAIPlanner

result = CadPipeline(planner=OpenAIPlanner()).run(
    request="a smooth curved glass",
    output_directory="runs",
    allow_defaults=True,
)
if result["status"] == "validated":
    print(result["delivery_directory"])
else:
    print(result["questions"], result["error"])
```

## تنظیم اجرای FreeCAD

در Debian با نصب استاندارد FreeCAD، Python سیستم و bindings آن خودکار شناسایی می‌شوند. تنظیم صریح برای نصب‌های دیگر:

```bash
export CAD_FREECAD_COMMAND='["/usr/bin/python3"]'
export CAD_FREECAD_LIB='/usr/lib/freecad-python3/lib'
```

`CAD_FREECAD_COMMAND` یک آرایهٔ JSON از executable و آرگومان‌هاست؛ shell اجرا نمی‌شود. مثلاً می‌توانید مسیر `FreeCADCmd.exe` را بدهید. اسکریپت تولیدشده خودش به Pydantic یا OpenAI وابسته نیست. روی نصب سازگار می‌توانید آن را با Python FreeCAD یا به‌عنوان macro اجرا کنید. اجرای چندبارهٔ macro اسناد فعلی کاربر را نمی‌بندد؛ فقط سندی را که خودش ساخته است مدیریت می‌کند.

در محیط آزمون، `freecadcmd --version` دچار crash شد ولی Python سیستم با bindings همان FreeCAD کار کرد. مسیر دوم واقعاً آزمایش شده است. اجرای FreeCADCmd در Windows/macOS در این محیط آزمایش نشده است.

## دانش و عملیات

فهرست ۳۹۳ سندِ شما در `document_chooser.json` حفظ شده است. فایل‌های واقعی را در `py_wiki/` کنار `main.py` قرار دهید. متادیتای فهرست به‌جای محتوای API استفاده نمی‌شود. اگر فایل‌ها موجود نباشند، هشدار ثبت می‌شود و مدل فقط قرارداد عملیات کامپایلر را در اختیار دارد.

بازیابی محلی BM25، کش بر اساس hash محتوا، تمام بخش‌های سند، نام منبع و کد کامل داخل fenced blocks را حفظ می‌کند. بودجهٔ متن ۱۲هزار کاراکتر است؛ بخش بزرگ به‌صورت کامل کنار گذاشته و گزارش می‌شود. انتخاب سند و خلاصه‌سازی، فراخوانی LLM یا embedding ندارند. برای درخواست‌های بزرگ‌تر، می‌توانید بودجه را در `KnowledgeIndex.retrieve` افزایش دهید یا اسناد بلند را در منبع به بخش‌های کوچک‌تر تقسیم کنید.

عملیات موجود: `box`, `cylinder`, `sphere`, `cone`, `profile` با line/arc/Bezier، `extrude`, `revolve`, `loft`, `cut`, `fuse`, `common`, `fillet`, `chamfer`, `transform`, `linear_pattern`, `polar_pattern`, `vessel`.

طول‌ها به mm، زاویه‌ها به degree و تعدادها به عدد بدون واحد تبدیل می‌شوند. پارامترها مقدار و واحد اصلی را نگه می‌دارند. عبارت‌ها فقط نام پارامتر و `+ - * /` دارند؛ فراخوانی تابع و Python دلخواه مجاز نیست. قواعد ابعادی هم بررسی می‌شوند: مثلاً `height+9` باید به `height+offset` تبدیل شود و `offset` منشأ و واحد مشخص داشته باشد. در طرح‌های مستقیمِ `--plan`، اعداد خام، بر حسب واحدهای قراردادی‌اند؛ در مسیر پرامپت، انتخاب‌های ابعادی باید پارامتر ثبت‌شده باشند.

## آزمون‌ها

```bash
python -m unittest discover -s tests -v
CAD_RUN_INTEGRATION=1 python -m unittest discover -s tests -v
```

آزمون‌های واقعی FreeCAD فقط با متغیر دوم اجرا می‌شوند. آزمون SDK از HTTP mock استفاده می‌کند و به کلید API نیاز ندارد. نتایج جلسهٔ تحویل در `verification/` هستند.

## حدود این نسخه و مهاجرت

این یک بازنویسی هسته با قرارداد v2 است؛ `StateGraph` و schema قدیمی، API سازگار ندارند. نقطهٔ اتصال جدید `CadPipeline.run` و خروجی آن `result.json` است. کدهای اولیه برای مقایسه در `original/` قرار دارند.

هندسهٔ ذخیره‌شده از `Part::Feature` و ارتباط عملیات ساخته می‌شود. مدل با تغییر `design.json` و بازتولید پارامتریک است؛ تاریخچهٔ کامل Sketcher/PartDesign با expressions قابل ویرایش زنده در GUI ساخته نشده است. STEP هم تاریخچهٔ پارامتریک را حمل نمی‌کند. اگر چنین تاریخچه‌ای بخشی از نیاز محصول است، باید backend جدا با native features و آزمون‌های ساختاری به کامپایلر اضافه شود.

این نسخه sweep، surfaces آزاد/NURBS، thickness عمومی، joints مونتاژ، CAM و FEA را پشتیبانی نمی‌کند. عملیات فاقد پشتیبانی باید با `unsupported` پاسخ داده شوند. `vessel` خانوادهٔ مشخصی از لیوان دورانی با قوس دایره‌ای است؛ فرم آزاد یا دستهٔ لیوان را به‌طور خودکار جایگزین نمی‌کند. Fillet/chamfer از شمارهٔ لبه استفاده می‌کنند و برای ویرایش‌های آینده نیاز به انتخاب هندسی پایدارتر دارند.

`validated` یعنی هندسه، آزمون‌های تعریف‌شده و رفت‌وبرگشت فایل قبول شده‌اند. این وضعیت تضمین درک کامل هر پرامپت، زیبایی بصری یا صحت مهندسی/ساخت نیست. کیفیت‌های غیرقابل اندازه‌گیری در `manual_review` ثبت می‌شوند. در این جلسه FreeCAD واقعی و SDK واقعی با mock آزمایش شدند؛ هیچ درخواست زنده به مدل زبانی ارسال نشد و صرفه‌جویی مالی یا نرخ موفقیت روی مجموعهٔ پرامپت‌ها اندازه‌گیری نشده است.
