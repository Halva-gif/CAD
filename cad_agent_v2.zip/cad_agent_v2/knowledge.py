"""Local, deterministic retrieval. Preserve fenced examples; never LLM-summarize."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re


def _tokens(text):
    return re.findall(r"[a-z][a-z0-9_]*|[\u0600-\u06ff]+",text.lower())


def markdown_chunks(text):
    """Split on headings outside fences. No prefix-only truncation of documents."""
    result, block, heading = [], [], ""
    fence = None
    for line in text.splitlines(keepends=True):
        stripped = line.lstrip()
        match = re.match(r"(`{3,}|~{3,})", stripped)
        if match:
            mark = match.group(1)[0]
            if fence is None:
                fence = mark
            elif fence == mark:
                fence = None
        if fence is None and re.match(r"^#{1,6} ",stripped):
            if block:
                result.append((heading,"".join(block)))
            heading = stripped.strip(); block = [line]
        else:
            block.append(line)
    if block:
        result.append((heading,"".join(block)))
    return result


class KnowledgeIndex:
    def __init__(self, catalog_path, wiki_directory, cache_directory):
        self.catalog_path = Path(catalog_path)
        self.wiki = Path(wiki_directory).resolve()
        self.cache = Path(cache_directory)
        self.cache.mkdir(parents=True,exist_ok=True)
        self.catalog = json.loads(self.catalog_path.read_text(encoding="utf-8")) if self.catalog_path.is_file() else {}
        if not isinstance(self.catalog,dict) or any(not isinstance(v,str) for v in self.catalog.values()):
            raise ValueError("document_chooser.json must map names to descriptions")

    def _path(self, name):
        if Path(name).name != name or not name.endswith(".md"):
            return None
        path = (self.wiki/name).resolve()
        return path if path.is_relative_to(self.wiki) and path.is_file() else None

    def _chunks(self, name):
        path = self._path(name)
        if path is None:
            return []
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        cache_path = self.cache/(digest+".json")
        if cache_path.is_file():
            try:
                records = json.loads(cache_path.read_text(encoding="utf-8"))
                return [{**item,"source":name,"sha256":digest} for item in records]
            except (ValueError,TypeError):
                pass
        records = [{"heading":h,"text":t} for h,t in markdown_chunks(data.decode("utf-8"))]
        cache_path.write_text(json.dumps(records,ensure_ascii=False),encoding="utf-8")
        return [{**item,"source":name,"sha256":digest} for item in records]

    @staticmethod
    def _rank(items, query, text_key):
        q = set(_tokens(query))
        if not q:
            return []
        documents = [Counter(_tokens(item[text_key])) for item in items]
        n = len(documents); average = sum(sum(d.values()) for d in documents)/max(n,1)
        df = Counter(term for d in documents for term in d)
        ranked = []
        for item,terms in zip(items,documents):
            length = sum(terms.values()); score = 0.0
            for term in q:
                frequency = terms[term]
                if frequency:
                    idf = math.log(1+(n-df[term]+0.5)/(df[term]+0.5))
                    score += idf*frequency*2.2/(frequency+1.2*(0.25+0.75*length/max(average,1)))
            if score > 0:
                ranked.append((score,item))
        return [item for score,item in sorted(ranked,key=lambda pair:-pair[0])]

    def retrieve(self, request, operations=(), max_files=8, max_characters=12000):
        aliases = []
        if any(term in request.lower() for term in ("glass","cup","vessel","لیوان","جام")):
            aliases.append("revolve arc curved hollow wall profile wire face")
        if any(term in request.lower() for term in ("hole","سوراخ")):
            aliases.append("cut pocket cylinder")
        for terms, expansion in [
            (("جعبه","مکعب","صفحه"),'box extrude pad profile'),
            (("استوانه",),'cylinder'), (("مخروط",),'cone'), (("کره",),'sphere'),
            (("دوران","چرخش"),'revolve rotation placement'),
            (("پخ",),'chamfer'), (("گرد کردن",),'fillet'),
            (("تکرار","آرایه"),'linear polar pattern array'),
            (("پروفایل",),'wire face arc bezier profile')]:
            if any(term in request for term in terms): aliases.append(expansion)
        query = " ".join([request,*operations,*aliases,"newDocument recompute saveAs"])
        items = [{"source":name,"text":name+" "+description} for name,description in self.catalog.items() if self._path(name)]
        selected = self._rank(items,query,"text")[:max_files]
        chunks = []
        for item in selected:
            chunks.extend(self._chunks(item["source"]))
        ranked = self._rank(chunks,query,"text")
        chosen, remaining, skipped = [], max_characters, 0
        for chunk in ranked:
            cost = len(chunk["text"])
            if cost > remaining:
                skipped += 1
                continue  # Never cut a Python example in the middle.
            chosen.append(chunk); remaining -= cost
        warnings = []
        if not items:
            warnings.append("No catalog document bodies are available. Catalog descriptions are metadata, not API knowledge. Using the tested compiler capability contract.")
        if skipped:
            warnings.append(f"Skipped {skipped} whole chunks that exceeded the context budget; increase the budget or split large source sections.")
        return {"selected_files":[x["source"] for x in selected],"snippets":chosen,
                "characters":max_characters-remaining,"warnings":warnings}
