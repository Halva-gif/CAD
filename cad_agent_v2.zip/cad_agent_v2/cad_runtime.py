"""Trusted FreeCAD implementation. Uses only the standard library and FreeCAD.

The compiler embeds this file into a self-contained generated script. It is not
an interpreter for Python produced by a language model.
"""
import json
import math
import os
from pathlib import Path
import sys
import traceback

from expressions import evaluate


def _load_freecad():
    # Use the interpreter shipped with, or ABI-compatible with, FreeCAD.
    library = os.environ.get("CAD_FREECAD_LIB")
    if library:
        sys.path.insert(0, library)
    for candidate in ("/usr/lib/freecad-python3/lib", "/usr/lib/freecad/lib"):
        if Path(candidate).is_dir() and candidate not in sys.path:
            sys.path.append(candidate)
    import FreeCAD as App
    import Part
    return App, Part


def _circle(a, b, c):
    x1, z1 = a; x2, z2 = b; x3, z3 = c
    d = 2 * (x1*(z2-z3) + x2*(z3-z1) + x3*(z1-z2))
    if abs(d) < 1e-9:
        raise ValueError("vessel bulge must be positive; straight walls use a profile/revolve")
    cx = ((x1*x1+z1*z1)*(z2-z3) + (x2*x2+z2*z2)*(z3-z1) + (x3*x3+z3*z3)*(z1-z2)) / d
    cz = ((x1*x1+z1*z1)*(x3-x2) + (x2*x2+z2*z2)*(x1-x3) + (x3*x3+z3*z3)*(x2-x1)) / d
    return cx, cz, math.hypot(x1-cx, z1-cz)


def _vessel(App, Part, f):
    h, rr, rb, t, bottom, bulge = (f[k] for k in
        ("height", "rim_radius", "base_radius", "wall_thickness", "bottom_thickness", "bulge"))
    if not 0 < t < min(rr, rb) or not 0 < bottom < h-t or not bulge > 0:
        raise ValueError("vessel needs positive dimensions, a wall thinner than both radii, bottom < height-wall, and positive bulge")
    # Concentric circular walls give exact normal wall thickness. A lip circle
    # of radius t/2 is tangent to both walls. Solve its highest point = height
    # and rightmost point = requested rim radius.
    re, ze = rr, h-t/2
    for _ in range(100):
        cx, cz, radius = _circle((rb, 0), ((rb+re)/2+bulge, ze/2), (re, ze))
        nx, nz = (re-cx)/radius, (ze-cz)/radius
        rn, zn = rr-t/2*(1-nx), h-t/2*(1-nz)
        if abs(rn-re)+abs(zn-ze) < 1e-10:
            break
        re, ze = rn, zn
    else:
        raise ValueError("rounded vessel lip did not converge")
    if nx <= 0 or cx >= min(rb, re):
        raise ValueError("vessel curvature too extreme for the supported circular-wall family")
    inner_radius = radius-t
    def inner_at(z):
        radicand = inner_radius**2-(z-cz)**2
        if radicand <= 0:
            raise ValueError("wall thickness/curvature leaves no valid inner wall")
        x = cx+math.sqrt(radicand)
        if x <= 0:
            raise ValueError("vessel interior crosses the rotation axis")
        return x, z
    itop = (re-t*nx, ze-t*nz)
    if itop[1] <= bottom:
        raise ValueError("vessel has no usable cavity above its bottom")
    ibottom = inner_at(bottom)
    imid = inner_at((itop[1]+bottom)/2)
    lip_center = (re-t/2*nx, ze-t/2*nz)
    lip_mid = (lip_center[0]-t/2*nz, lip_center[1]+t/2*nx)
    v = lambda p: App.Vector(p[0], 0, p[1])
    axis_bottom = v((0,0)); axis_inner = v((0,bottom))
    edges = [Part.makeLine(axis_bottom, v((rb,0))),
             Part.Arc(v((rb,0)), v(((rb+re)/2+bulge, ze/2)), v((re,ze))).toShape(),
             Part.Arc(v((re,ze)), v(lip_mid), v(itop)).toShape(),
             Part.Arc(v(itop), v(imid), v(ibottom)).toShape(),
             Part.makeLine(v(ibottom), axis_inner), Part.makeLine(axis_inner, axis_bottom)]
    wire = Part.Wire(edges)
    if not wire.isClosed() or not wire.isValid():
        raise ValueError("vessel profile is not closed and valid")
    shape = Part.Face(wire).revolve(App.Vector(0,0,0), App.Vector(0,0,1), 360)
    # Verify the actual solid, including cavity, bottom and normal wall probes.
    z = (bottom+itop[1])/2
    ro = cx+math.sqrt(radius**2-(z-cz)**2)
    normal = ((ro-cx)/radius, (z-cz)/radius)
    wall_point = v((ro-t/2*normal[0], z-t/2*normal[1]))
    boundary = Part.Compound(shape.Faces)
    normal_half_thickness = boundary.distToShape(Part.Vertex(wall_point))[0]
    checks = [
        ("open_cavity", not shape.isInside(App.Vector(0,0,(bottom+h)/2), 1e-7, True)),
        ("closed_bottom", shape.isInside(App.Vector(0,0,bottom/2), 1e-7, True)),
        ("wall_material", shape.isInside(wall_point, 1e-7, True)),
        ("normal_wall_thickness", abs(normal_half_thickness-t/2) <= 1e-5),
        ("height", abs(shape.optimalBoundingBox(False,False).ZLength-h) <= 1e-5),
    ]
    return shape, [{"kind":"vessel", "target":f["id"], "passed":bool(passed),
                    "detail":name} for name, passed in checks]


def _metrics(name, shape):
    if shape.isNull():
        return {"object_name":name, "is_null":True, "is_valid":False,
                "solid_count":0, "volume":0.0, "bbox":None}
    # Generic BoundBox can overestimate curved surfaces using control poles.
    bb = shape.optimalBoundingBox(False,False)
    return {"object_name":name, "is_null":False, "is_valid":bool(shape.isValid()),
            "solid_count":len(shape.Solids), "volume":float(shape.Volume),
            "bbox":{"x_min":bb.XMin, "y_min":bb.YMin, "z_min":bb.ZMin,
                    "x_max":bb.XMax, "y_max":bb.YMax, "z_max":bb.ZMax}}


def _resolved_payload(design):
    parameters = design["canonical_parameters"]
    scalar_keys = {"length", "width", "height", "radius", "radius1", "radius2", "angle",
                   "rim_radius", "base_radius", "wall_thickness", "bottom_thickness", "bulge",
                   "expected", "minimum", "maximum", "x", "y", "z",'count','angle_step'}
    def resolve(item):
        if isinstance(item, list):
            return [resolve(x) for x in item]
        if isinstance(item, dict):
            return {k:evaluate(v, parameters,limit=1e15 if k in ('minimum','maximum') else 100000) if k in scalar_keys else resolve(v) for k,v in item.items()}
        return item
    return resolve(design)


def _build(App, Part, doc, f, shapes):
    def v(p):
        return App.Vector(p["x"],p["y"],p["z"])
    def positive(*keys):
        if any(f[k] <= 1e-7 for k in keys):
            raise ValueError(f"{f['id']}: {keys} must be positive")
    op = f["op"]
    builtin = []
    refs = []
    if op == "box":
        positive("length","width","height")
        shape = Part.makeBox(f["length"],f["width"],f["height"],v(f["origin"]))
    elif op == "cylinder":
        positive("radius","height")
        shape = Part.makeCylinder(f["radius"],f["height"],v(f["origin"]))
    elif op == "sphere":
        positive("radius")
        shape = Part.makeSphere(f["radius"],v(f["center"]))
    elif op == "cone":
        positive("height")
        if min(f["radius1"],f["radius2"]) < 0 or max(f["radius1"],f["radius2"]) <= 1e-7:
            raise ValueError("cone radii must be nonnegative and not both zero")
        shape = Part.makeCone(f["radius1"],f["radius2"],f["height"],v(f["origin"]))
    elif op == "profile":
        edges = []
        starts, ends = [], []
        for segment in f["segments"]:
            if segment["kind"] == "line":
                start, end = v(segment["start"]), v(segment["end"])
                edge = Part.makeLine(start,end)
            elif segment["kind"] == "arc":
                start, end = v(segment["start"]), v(segment["end"])
                edge = Part.Arc(start,v(segment["mid"]),end).toShape()
            else:
                points = [v(p) for p in segment["points"]]
                start, end = points[0],points[-1]
                curve = Part.BezierCurve(); curve.setPoles(points)
                edge = curve.toShape()
            starts.append(start); ends.append(end); edges.append(edge)
        if any((ends[i]-starts[(i+1)%len(starts)]).Length > 1e-7 for i in range(len(starts))):
            raise ValueError("profile segments must meet in the declared order and close exactly")
        shape = Part.Wire(edges)
        if not shape.isClosed():
            raise ValueError("profile is not closed")
        # Face() rejects non-planar or self-intersecting profiles in later checks.
        face = Part.Face(shape)
        if not face.isValid() or face.Area <= 1e-10:
            raise ValueError("profile does not enclose a valid planar area")
    elif op == "extrude":
        refs = [f["profile"]]
        vector = v(f["vector"])
        if vector.Length < 1e-7:
            raise ValueError("extrusion vector is zero")
        shape = Part.Face(shapes[f["profile"]]).extrude(vector)
    elif op == "revolve":
        refs = [f["profile"]]
        if not 0 < f["angle"] <= 360 or v(f["axis"]).Length < 1e-7:
            raise ValueError("revolve needs a nonzero axis and angle in (0,360]")
        shape = Part.Face(shapes[f["profile"]]).revolve(v(f["origin"]),v(f["axis"]),f["angle"])
    elif op == "loft":
        refs = f["profiles"]
        shape = Part.makeLoft([shapes[n] for n in refs],True,f["ruled"])
    elif op == "cut":
        refs = [f["base"],f["tool"]]
        shape = shapes[f["base"]].cut(shapes[f["tool"]]).removeSplitter()
        if abs(shape.Volume-shapes[f["base"]].Volume) <= 1e-9:
            raise ValueError("cut removes no material; check placement and tool overlap")
    elif op in ("fuse","common"):
        refs = f["inputs"]
        shape = shapes[refs[0]]
        for ref in refs[1:]:
            shape = shape.fuse(shapes[ref]) if op == "fuse" else shape.common(shapes[ref])
        shape = shape.removeSplitter()
    elif op in ("fillet","chamfer"):
        positive("radius")
        refs = [f["base"]]; source = shapes[f["base"]]
        if len(set(f["edges"])) != len(f["edges"]) or any(i < 1 or i > len(source.Edges) for i in f["edges"]):
            raise ValueError("invalid or duplicate 1-based edge index")
        selected = [source.Edges[i-1] for i in f["edges"]]
        shape = source.makeFillet(f["radius"],selected) if op == "fillet" else source.makeChamfer(f["radius"],selected)
    elif op == "transform":
        refs = [f["base"]]; shape = shapes[f["base"]].copy()
        axis = v(f["axis"])
        if axis.Length < 1e-7:
            raise ValueError("rotation axis is zero")
        # Apply a rigid transform about the world origin to existing placement.
        shape.Placement = App.Placement(v(f["translation"]), App.Rotation(axis,f["angle"])).multiply(shape.Placement)
    elif op == "vessel":
        shape, builtin = _vessel(App,Part,f)
    elif op in ('linear_pattern','polar_pattern'):
        count=int(round(f['count']))
        if abs(f['count']-count)>1e-9 or not 1<=count<=32:
            raise ValueError('pattern count must be an integer in [1,32]')
        refs=[f['base']]; source=shapes[f['base']]
        if len(source.Solids)*count>256:
            raise ValueError('pattern would exceed the 256-solid construction budget')
        if op=='linear_pattern' and count>1 and v(f['delta']).Length<1e-7:
            raise ValueError('linear pattern step is zero')
        if op=='polar_pattern' and (v(f['axis']).Length<1e-7 or not 0<abs(f['angle_step'])<360):
            raise ValueError('polar pattern needs a nonzero axis and angle step in (-360,360), excluding zero')
        copies=[]
        for i in range(count):
            copy=source.copy()
            if op=='linear_pattern':
                copy.translate(v(f['delta'])*i)
            else:
                copy.rotate(v(f['origin']),v(f['axis']),f['angle_step']*i)
            if any(copy.common(previous).Volume>1e-7 for previous in copies):
                raise ValueError('pattern instances overlap; adjust spacing before cutting or fusing')
            copies.append(copy)
        shape=Part.Compound(copies)
        builtin=[{'kind':'pattern_count','target':f['id'],
                  'passed':len(shape.Solids)==count*len(source.Solids),'detail':f'{count} nonoverlapping pattern instances'}]
    else:
        raise ValueError(f"unsupported operation: {op}")
    if shape.isNull() or not shape.isValid() or (op != "profile" and (not shape.Solids or shape.Volume <= 1e-9)):
        raise ValueError(f"{f['id']}: invalid, empty or non-solid result")
    if len(shape.Solids)>256:
        raise ValueError('construction exceeds the 256-solid budget')
    obj = doc.addObject("Part::Feature",f["id"])
    obj.Label = f["intent"][:120]
    obj.Shape = shape
    obj.addProperty("App::PropertyString","Operation","Construction"); obj.Operation = op
    obj.addProperty("App::PropertyLinkList","Inputs","Construction")
    obj.Inputs = [doc.getObject(ref) for ref in refs]
    return shape, builtin


def _acceptance(App, shape, check):
    kind = check["kind"]
    if kind == "bbox":
        actual = getattr(shape.optimalBoundingBox(False,False), check["axis"].upper()+"Length")
        passed = abs(actual-check["expected"]) <= check["tolerance"]
        detail = f"{actual:.8g} vs {check['expected']:.8g} mm"
    elif kind == "point":
        p = check["point"]
        actual = bool(shape.isInside(App.Vector(p["x"],p["y"],p["z"]),1e-7,True))
        passed = actual == check["inside"]
        detail = f"inside={actual}, expected={check['inside']}"
    else:
        actual = shape.Volume
        passed = check["minimum"] <= actual <= check["maximum"]
        detail = f"volume={actual:.8g} mm^3"
    return {"kind":kind, "target":check["target"], "passed":bool(passed),
            "detail":check["reason"]+": "+detail}


def run_model(design, directory, request=""):
    directory = Path(directory).resolve(); directory.mkdir(parents=True,exist_ok=True)
    report_path = directory/"runtime_report.json"
    report = {"ok":False, "error":None, "failed_feature":None, "version":[],
              "stage":"loading_runtime", "failure_kind":None,
              "fcstd_path":None, "step_path":None, "saved":False, "step_roundtrip":False,
              "metrics":[], "feature_metrics":[], "checks":[]}
    App = None; doc = None; reopened = None
    try:
        App, Part = _load_freecad(); report["version"] = App.Version()
        raw = design; design = _resolved_payload(design)
        report['stage']='geometry'
        doc = App.newDocument("GeneratedCAD")
        doc.openTransaction("Build validated CAD program")
        meta = doc.addObject("App::FeaturePython","Parameters")
        meta.addProperty("App::PropertyString","DesignJSON","Source")
        meta.DesignJSON = json.dumps(raw,ensure_ascii=False)
        meta.addProperty("App::PropertyString","Request","Source"); meta.Request = request
        shapes = {}
        for feature in design["features"]:
            report["failed_feature"] = feature["id"]
            shape, builtin = _build(App,Part,doc,feature,shapes)
            shapes[feature["id"]] = shape
            report["feature_metrics"].append(_metrics(feature["id"],shape))
            report["checks"].extend(builtin)
        report["failed_feature"] = None
        final_ids = {o["feature"] for o in design["outputs"]}
        for feature in design["features"]:
            obj = doc.getObject(feature["id"])
            if App.GuiUp:
                obj.ViewObject.Visibility = feature["id"] in final_ids
        for output in design["outputs"]:
            shape = shapes[output["feature"]]
            doc.getObject(output["feature"]).Label = output["label"]
            report["metrics"].append(_metrics(output["feature"],shape))
            report["checks"].append({"kind":"solid_count", "target":output["feature"],
                "passed":len(shape.Solids)==output["expected_solids"], "detail":f"expected {output['expected_solids']} solids, got {len(shape.Solids)}"})
        for check in design["checks"]:
            report["checks"].append(_acceptance(App,shapes[check["target"]],check))
        doc.recompute(); doc.commitTransaction(); report['stage']='artifacts'
        fcstd = directory/"candidate.FCStd"; step = directory/"candidate.step"
        doc.saveAs(str(fcstd))
        # Keep intermediary profiles/tools out of the exported STEP assembly.
        Part.export([doc.getObject(o["feature"]) for o in design["outputs"]],str(step))
        original_metrics = list(report["metrics"])
        App.closeDocument(doc.Name); doc = None
        reopened = App.openDocument(str(fcstd))
        restored = [_metrics(o["feature"],reopened.getObject(o["feature"]).Shape) for o in design["outputs"]]
        def equivalent(a,b):
            if a["is_null"] or not a["is_valid"] or a["solid_count"] != b["solid_count"]:
                return False
            if abs(a["volume"]-b["volume"]) > max(1e-5, b["volume"]*1e-8):
                return False
            return all(abs(a["bbox"][k]-b["bbox"][k]) <= 1e-5 for k in a["bbox"])
        report["saved"] = fcstd.is_file() and fcstd.stat().st_size > 0 and all(equivalent(a,b) for a,b in zip(restored,original_metrics))
        imported = Part.read(str(step))
        total_volume = sum(m["volume"] for m in original_metrics)
        roundtrip = (not imported.isNull() and imported.isValid() and
                     len(imported.Solids)==sum(m["solid_count"] for m in original_metrics) and
                     abs(imported.Volume-total_volume) <= max(1e-4,total_volume*1e-7))
        report["step_roundtrip"] = bool(roundtrip)
        report["fcstd_path"] = str(fcstd); report["step_path"] = str(step)
        report["ok"] = bool(report["saved"] and roundtrip and all(c["passed"] for c in report["checks"]))
        report['stage']='complete'
    except Exception:
        report["error"] = traceback.format_exc()[-6000:]
        report['failure_kind']='environment' if report['stage'] in ('loading_runtime','artifacts') else 'geometry'
        if doc is not None:
            try:
                doc.abortTransaction()
            except Exception:
                pass
    finally:
        if App is not None:
            for opened in (doc,reopened):
                if opened is not None:
                    try:
                        App.closeDocument(opened.Name)
                    except Exception:
                        pass
        report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    return report
