"""Small arithmetic language; deliberately no eval(), calls, attributes or imports."""
import ast
import math
import operator
import re

MAX_VALUE = 100_000.0
UNITS = {"mm": 1.0, "cm": 10.0, "m": 1000.0, "in": 25.4,
         "deg": 1.0, "rad": 180.0 / math.pi, "count": 1.0}
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub,
        ast.Mult: operator.mul, ast.Div: operator.truediv}


def expression_names(value):
    if not isinstance(value, str):
        return set()
    tree = _parse(value)
    return {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}


def _parse(value):
    if len(value) > 256:
        raise ValueError("expression too long")
    try:
        tree = ast.parse(value, mode="eval")
    except SyntaxError as exc:
        raise ValueError("invalid arithmetic expression") from exc
    if sum(1 for _ in ast.walk(tree)) > 64:
        raise ValueError("expression too complex")
    allowed = (ast.Expression, ast.Constant, ast.Name, ast.Load, ast.BinOp,
               ast.UnaryOp, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.UAdd, ast.USub)
    if any(not isinstance(node, allowed) for node in ast.walk(tree)):
        raise ValueError("only numbers, parameter names and + - * / are allowed")
    return tree


def evaluate(value, parameters, limit=MAX_VALUE):
    def visit(node):
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            return float(node.value)
        if isinstance(node, ast.Name):
            if node.id not in parameters or parameters[node.id] is None:
                raise ValueError(f"unresolved parameter: {node.id}")
            return float(parameters[node.id])
        if isinstance(node, ast.UnaryOp):
            return visit(node.operand) * (-1 if isinstance(node.op, ast.USub) else 1)
        if isinstance(node, ast.BinOp):
            try:
                return _OPS[type(node.op)](visit(node.left), visit(node.right))
            except ZeroDivisionError as exc:
                raise ValueError("division by zero") from exc
        raise ValueError("invalid arithmetic expression")
    result = visit(_parse(value)) if isinstance(value, str) else value
    if type(result) not in (int, float) or not math.isfinite(result) or abs(result) > limit:
        raise ValueError(f"scalar must be finite and within +/-{limit:g}")
    return float(result)


def number_tokens(text):
    """Numbers in ordinary decimal notation, including Persian/Arabic digits."""
    normalized = str(text).translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩٫−", "01234567890123456789.-"))
    normalized = re.sub(r"(?<=\d)\s*[xX×]\s*(?=\d)", " ", normalized)
    pattern = r"(?<![\w.])[+-]?(?:\d+(?:\.\d+)?|\.\d+)(?:[eE][+-]?\d+)?(?![\d.])"
    return [float(match.group()) for match in re.finditer(pattern,normalized)
            if not re.match(r"[dD]\b",normalized[match.end():])]


def dimensionality(value, parameter_units):
    """Return (length power, angle power); None is the universal zero literal."""
    def visit(node):
        if isinstance(node,ast.Expression): return visit(node.body)
        if isinstance(node,ast.Constant) and type(node.value) in (int,float):
            return None if node.value==0 else (0,0)
        if isinstance(node,ast.Name):
            unit=parameter_units[node.id]
            return (0,1) if unit in ('deg','rad') else (0,0) if unit=='count' else (1,0)
        if isinstance(node,ast.UnaryOp): return visit(node.operand)
        if isinstance(node,ast.BinOp):
            a,b=visit(node.left),visit(node.right)
            if isinstance(node.op,(ast.Add,ast.Sub)):
                if a is None: return b
                if b is None: return a
                if a!=b: raise ValueError('cannot add/subtract values of different dimensions; declare dimensional offsets as parameters')
                return a
            if a is None or (b is None and isinstance(node.op,ast.Mult)): return None
            if b is None: raise ValueError('division by zero')
            sign=-1 if isinstance(node.op,ast.Div) else 1
            return tuple(x+sign*y for x,y in zip(a,b))
        raise ValueError('invalid dimensional expression')
    if isinstance(value,str): return visit(_parse(value))
    return None if value==0 else (0,0)
