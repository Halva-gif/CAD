"""Acceptance is deterministic. A model cannot declare its own code correct."""
import math
from pathlib import Path


def validate_run(design, run):
    checks = []
    def check(kind,target,passed,detail):
        checks.append({"kind":kind,"target":target,"passed":bool(passed),"detail":detail})
    check("process","FreeCAD",run.get("return_code")==0 and run.get("ok"),run.get("error") or "Process exited successfully")
    runtime = run.get("runtime") or {}
    directory = Path(run["attempt_directory"]).resolve()
    for key in ("fcstd_path","step_path"):
        candidate = runtime.get(key)
        path = Path(candidate).resolve() if isinstance(candidate,str) else None
        valid = path is not None and path.is_relative_to(directory) and path.is_file() and path.stat().st_size > 0
        check("artifact",key,valid,"Nonempty artifact inside this attempt directory")
    check("roundtrip","FCStd",runtime.get("saved") is True,"FCStd reopened and matched the original shapes")
    check("roundtrip","STEP",runtime.get("step_roundtrip") is True,"STEP reimported; validity, volume and solid count matched")
    metrics = runtime.get("metrics") or []
    by_name = {m.get("object_name"):m for m in metrics if isinstance(m,dict)}
    expected = {o.feature for o in design.outputs}
    check("objects","outputs",set(by_name)==expected and len(metrics)==len(expected),"Exact final output set")
    for output in design.outputs:
        metric = by_name.get(output.feature,{})
        volume = metric.get("volume")
        valid_volume = type(volume) in (int,float) and math.isfinite(volume) and volume > 0
        check("shape",output.feature,metric.get("is_valid") is True and metric.get("is_null") is False and valid_volume and metric.get("solid_count")==output.expected_solids,"Valid nonempty solid with positive volume and expected solid count")
    runtime_checks = runtime.get("checks") or []
    check("checks","acceptance",len(runtime_checks)>=len(design.checks)+len(design.outputs),"Runtime produced all declared acceptance checks")
    for item in runtime_checks:
        check(item.get("kind","unknown"),item.get("target","unknown"),item.get("passed") is True,item.get("detail",""))
    return {"passed":all(c["passed"] for c in checks),"checks":checks,
            "scope":"Geometry, declared acceptance checks and artifact round trips. Natural-language completeness and aesthetics are not certified.",
            "manual_review":design.manual_review}


def lock_repair(original, revised):
    """Do not repair a failure by weakening facts or deleting acceptance checks."""
    old = {p.name:p.model_dump() for p in original.parameters}
    new = {p.name:p.model_dump() for p in revised.parameters}
    if any(new.get(name) != value for name,value in old.items()):
        raise ValueError("repair changed or dropped resolved parameters")
    if original.goal != revised.goal or original.constraints != revised.constraints:
        raise ValueError("repair changed user intent or constraints")
    if [c.model_dump() for c in original.checks] != [c.model_dump() for c in revised.checks]:
        raise ValueError("repair changed acceptance checks")
    if [o.model_dump() for o in original.outputs] != [o.model_dump() for o in revised.outputs]:
        raise ValueError("repair changed final output contract")
    if original.manual_review != revised.manual_review:
        raise ValueError("repair changed declared review limitations")
