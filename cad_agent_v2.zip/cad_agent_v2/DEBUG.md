# FreeCAD CAD Agent v2 — راهنمای دیباگ

این فایل وضعیت نسخهٔ اصلاح‌شده را توصیف می‌کند. نسخهٔ قبلی در `original/DEBUG.md` است. گزارش ریشهٔ خطاها و تصمیم معماری در `REPORT_FA.md` و دستورهای اجرا در `README.md` آمده‌اند.

## جریان اجرا

```text
CadPipeline.run(request, output_directory, allow_defaults)
  -> KnowledgeIndex.retrieve
  -> OpenAIPlanner.propose -> PlanResponse / CadDesign
  -> validate_request_facts / validate_physical_dimensions
  -> compile_design
  -> FreeCADRunner.run
  -> run_model: build -> declared checks -> save -> reopen -> STEP reimport
  -> validate_run
  -> publish accepted artifacts, or bounded repair
```

`--plan` و `--demo` مرحلهٔ مدل زبانی را حذف می‌کنند. `--demo` ابعاد فرضی ثبت‌شده را صریحاً فعال می‌کند. وضعیت‌های خروجی: `validated`, `needs_clarification`, `unsupported`, `failed`, `environment_error`.

## نخست کجا را ببینیم؟

| علامت | فایل/مقدار مفید | اقدام |
|---|---|---|
| مقدار گمشده | `questions`, `design.parameters` | دادهٔ لازم یا سیاست ابعاد فرضی را مشخص کنید |
| نقض schema یا واحد | `attempts[].error.contract_error` | نام‌ها، واحد، evidence و عبارت‌ها را بررسی کنید |
| دستور پشتیبانی‌نشده | `status=unsupported` | عملیات را به schema/compiler اضافه و آزمون کنید |
| هندسهٔ نامعتبر | `run_result.runtime.failed_feature`, `error` | همان مرحله و پیش‌نیازهایش را در design بررسی کنید |
| هندسه معتبر ولی خواسته محقق نشده | `validation.checks` با passed=false | جای سوراخ، اندازه، حفره و material probes را بررسی کنید |
| خروجی ذخیره نشده | `runtime.stage`, `saved`, `step_roundtrip` | نسخهٔ FreeCAD، مسیر خروجی و import/export را بررسی کنید |
| runtime بارگیری نمی‌شود | `failure_kind=environment`, `stdout.log`, `stderr.log` | executable و ABI Python را درست کنید؛ prompt repair مفید نیست |
| دانش پیدا نمی‌شود | `knowledge.warnings`, `selected_files`, `snippets` | فایل واقعی باید در py_wiki باشد؛ متادیتای کاتالوگ متن API نیست |

هر تلاش یک پوشهٔ جدید و کد و لاگ خودش دارد. `runtime_report.json` از فرایند FreeCAD می‌آید. `result.json` و `validation.json` از برنامهٔ اصلی می‌آیند. نبود گزارش runtime یا return code غیرصفر پذیرش نمی‌شود. Candidate ناموفق ممکن است برای تشخیص حفظ شود، ولی `model.FCStd` و `model.step` نهایی فقط پس از پذیرش ایجاد می‌شوند.

## قواعد مهم

- کلیدهای اتصال، id ویژگی و نام پارامتر هستند. یک نام پارامتر در کل طرح یکتا است؛ برای چند قطعه نام‌های prefixed استفاده کنید.
- هر خروجی باید Solid باشد، حجم مثبت و تعداد Solid مورد انتظار داشته باشد و حداقل یک آزمون پذیرش داشته باشد.
- `profile` باید Wire بسته و مرتب و دارای Face معتبر باشد. Edgeهای جدا یا Compound از قوس‌ها معادل Face نیستند.
- `revolve` فقط پروفایل بسته را مصرف می‌کند. محور غیرصفر و زاویه در `(0,360]` لازم است.
- `cut` باید ماده حذف کند؛ ابزار خارج از جسم رد می‌شود. ابزار عبوری بهتر است از دو طرف کمی امتداد داشته باشد و این مقدار به‌عنوان پارامتر ثبت شود.
- `linear_pattern` و `polar_pattern` count صحیح در `[1,32]` دارند. نمونه‌ها نباید هم‌پوشانی حجمی داشته باشند. حداکثر ۲۵۶ Solid در یک مرحله مجاز است.
- `BoundBox` ساده می‌تواند برای سطح منحنی بیش‌برآورد کند؛ اندازه‌گیریِ این نسخه از `optimalBoundingBox(False,False)` استفاده می‌کند.
- repair همهٔ پارامترهای اولیه، intent، خروجی‌ها، manual_review و آزمون‌ها را حفظ می‌کند؛ کاهش ابعاد فرضی یا تغییر tolerance برای قبول‌شدن مجاز نیست.
- ظاهر یا intent کامل از مثبت بودن حجم نتیجه‌گیری نمی‌شود. `manual_review` و scope اعتبارسنجی را همراه خروجی به کاربر نشان دهید.

نمونهٔ standalone اصلاح‌شده در `cad_testing.py` است. این فایل از همان کامپایلرِ نمونهٔ لیوان ساخته شده و به SDK یا Pydantic وابسته نیست. برای تغییر ابعاد، `examples/glass.json` را تغییر دهید و کد را دوباره تولید کنید.

## وضعیت آزمون جلسهٔ تحویل

۵۰ آزمون موفق، شامل ۱۷ روش آزمون integration با FreeCAD واقعی و subtestهای چند عملیات؛ SDK با HTTP mock آزمایش شد. Python برنامه 3.12، Python سازگار FreeCAD سیستم 3.13، FreeCAD 1.0.0، OpenAI SDK 2.54.0 و Pydantic 2.14.1 در اجرای نهایی استفاده شدند. نسخه‌های dependency در `requirements.lock.txt` و لاگ کامل در `verification/tests.txt` هستند.

فراخوانی زندهٔ مدل، کیفیت بازیابی روی فایل‌های دانش غایب و نرخ semantic fidelity روی مجموعهٔ پرامپت‌ها آزمایش نشدند.
